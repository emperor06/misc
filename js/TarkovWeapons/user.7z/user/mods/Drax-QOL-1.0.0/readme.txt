Add to user/mods

Drax Quality of Life
