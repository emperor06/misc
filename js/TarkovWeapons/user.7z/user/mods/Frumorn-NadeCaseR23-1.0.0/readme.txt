Add the Frumorn-NadeCaseR23 folder in user/mods

Add these lines to your server.config.json in user folder

{
	"name": "NadeCaseR23",
	"author": "Frumorn",
	"version": "1.0.0",
	"enabled": true
}

This should work for R23, it includes locale files for the english version which adds a proper description and name for the item