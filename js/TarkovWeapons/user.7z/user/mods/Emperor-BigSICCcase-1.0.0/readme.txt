Add to user/mods

Replaces vanilla Small ICC Case (25 slots) with a 4x bigger one